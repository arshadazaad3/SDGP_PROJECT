TextClassifier.py => The Naive bayes classifier where the model is created.
tweet_classifier_model => this is the final model created by the above file
tweetScrapeAndSave => The similar searches will be passed as arguments. Tweets are extracted and filtered.

testModel => This is where the prediction is done and a string is returned
