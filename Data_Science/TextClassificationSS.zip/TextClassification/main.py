import testModel
finalResult = testModel.final_result_achieved
print("Final Result : ", finalResult)